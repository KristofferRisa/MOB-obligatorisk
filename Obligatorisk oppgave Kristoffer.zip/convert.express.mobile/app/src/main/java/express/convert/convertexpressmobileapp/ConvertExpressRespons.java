package express.convert.convertexpressmobileapp;

public class ConvertExpressRespons {
    String header;
    String description;
}
