package express.convert.convertexpressmobileapp;

/**
 * Created by kristofferrisa on 15.11.2017.
 */

public class ConvertExpressRespons {
    String header;
    String description;
}
